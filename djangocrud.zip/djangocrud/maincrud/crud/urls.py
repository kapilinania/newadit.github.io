from django.urls import path
from . import views
from .views import myform

urlpatterns = [
    path('', views.index, name='index'),
    path('showdata', views.task_list, name='task_list'),
    path('add/', views.add_data, name='add'),
    path('add/addrecord/', views.addrecord, name='addrecord'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('form/', views.myform, name="myform"),


]
