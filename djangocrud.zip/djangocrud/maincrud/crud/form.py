from django import forms


class CreateForm(forms.Form):
    name = forms.CharField(max_length=255)
    email = forms.EmailField()
    message = forms.CharField(max_length=100)
    file = forms.FileField()

