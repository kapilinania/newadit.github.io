from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from .models import Task
from django.urls import reverse
import os
from django.conf import settings

# for form
from .form import CreateForm


def index(request):
    return render(request, 'index.html')


# Create your views here.
def task_list(request):
    tasks = Task.objects.all().values()
    template = loader.get_template('showdata.html')
    context = {
        'tasks': tasks,
    }
    return HttpResponse(template.render(context, request))


def add_data(request):
    template = loader.get_template('add.html')
    return HttpResponse(template.render({}, request))


# ---insert the record  -----
def addrecord(request):
    x = request.POST['name']
    y = request.POST['email']
    z = request.POST['fname']
    task = Task(name=x, email=y, fname=z)
    task.save()
    return HttpResponseRedirect(reverse('task_list'))


# ---delete the record ------

def delete(request, id):
    tasks = Task.objects.get(id=id)
    tasks.delete()
    return HttpResponseRedirect(reverse('task_list'))


# -----here we are define form ----

def myform(request):
    if request.method == 'POST':
        form = CreateForm(request.POST,request.FILES)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            file = form.cleaned_data['file']
            with open(os.path.join(settings.MEDIA_ROOT, file.name), "wb+") as destination_file:
                for chunk in file.chunks():
                    destination_file.write(chunk)
            return render(request, 'success.html', {'name': name, 'email': email, 'message': message,'file':file})
    else:
        form = CreateForm()

    return render(request, 'templateData.html', {'form': form})

